clear
clear global
clc
close all