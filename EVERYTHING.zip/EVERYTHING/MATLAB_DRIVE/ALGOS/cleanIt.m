clear;
close all;
clear global;
clc;
